library(dplyr)
library(ggplot2)
library(zoo)
library(roll)

GenomeMapping <- function(fileName, windowK = 0){
	depth <- read.table(fileName, header = F)
	colnames(depth) <- c("Chromosome", "Position", "Coverage")
	# Preparing the file name
	sampleName <- gsub("\\..*","", depth[1,1])
	coverage <- mean(depth$Coverage)
	plotTitle <- gsub(".*/","", depth$Chromosome[1])
	plotTitle <- paste0(plotTitle, " Coverage: Mean ",round(coverage,3),"x")
	
	if(windowK == 0){
		message("Using a window size of 0.1%")
		windowK <- floor(0.001*nrow(depth))
	}

	depth <- depth %>% mutate(MeanCoverage = rollmean(Coverage, k = windowK,align = "center", fill = NA),
				  SDCoverage = rollapply(Coverage, width = windowK, align = "center", fill = NA, FUN = sd),
				  CVCoverage = SDCoverage/MeanCoverage)
	p1 <- depth %>% ggplot(aes(x = Position, y = MeanCoverage, colour = CVCoverage)) + geom_line() + theme_bw() +
		geom_hline(yintercept = coverage, colour = "red", lty = 2) + scale_y_continuous(limits = c(0,40), breaks = scales:::pretty_breaks(n = 8)) +
		ggtitle(label = plotTitle, subtitle = paste0("Sliding window of ", windowK, "bp")) + ylab("Base Coverage") +
		scale_color_manual(name = "Likelihood of Stacking", values = c("[0,1]" ="green", "(1,2]" = "yellow", "(2,Inf]" = "red"),
		labels = c("Low", "Medium", "High"))
	
	return(p1)
}

# Loading the Data
setwd("../Ecoli/Depths/")

GenomeMapping("K12Depth.tab.gz")
depth <- read.table("K12Depth.tab.gz", header = F)
colnames(depth) <- c("Chromosome", "Position", "Coverage")

windowK = 4926
depth <- depth %>% mutate(MeanCoverage = roll_mean(Coverage, width = windowK),
			  SDCoverage = roll_sd(Coverage, width = windowK),
			  CVCoverage = SDCoverage/MeanCoverage) %>% 
		  mutate(CVCoverage = sapply(CVCoverage , function(x){ifelse(is.infinite(CVCoverage),NA, x)}))
basePlotColour <- ifelse(depth$CVCoverage < 1, "green", 
			ifelse(depth$CVCoverage >= 1 & depth$CVCoverage < 2, "yellow", "red"))

plot(y = depth$MeanCoverage, x = depth$Position, col = basePlotColour, type = "l")

depth %>% ggplot(aes(x = Position, y = MeanCoverage)) + geom_line() + theme_bw() +
	geom_hline(yintercept = 22, colour = "red", lty = 2) + scale_y_continuous(limits = c(0,40), breaks = scales:::pretty_breaks(n = 8)) +
	ggtitle(label = "blah", subtitle = paste0("Sliding window of ", windowK, "bp")) + ylab("Base Coverage") 

depth %>% filter(CVCoverage > 2)%>% ggplot(aes(x = Position, y = MeanCoverage)) + geom_line() + theme_bw() +
	geom_hline(yintercept = 22, colour = "red", lty = 2) + scale_y_continuous(limits = c(0,40), breaks = scales:::pretty_breaks(n = 8)) +
	ggtitle(label = "blah", subtitle = paste0("Sliding window of ", windowK, "bp")) + ylab("Base Coverage") 


depth %>% ggplot(aes(x = Position, y = CVCoverage)) + geom_line() + theme_bw() +
	ggtitle(label = "blah", subtitle = paste0("Sliding window of ", windowK, "bp")) + ylab("CV") 
